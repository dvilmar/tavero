# Handoff: Tavero Design System — UI Improvements

## Overview

Este paquete describe las mejoras de diseño para **Tavero**, una plataforma de menú digital para bares y restaurantes. Contiene dos productos:

- **tavero-app** — App móvil (Expo / React Native) para propietarios de bares
- **tavero-web** — Web viewer (Next.js) para clientes que escanean el QR

Los archivos HTML de este paquete son **prototipos de referencia de diseño** creados para comunicar la intención visual. La tarea es **reimplementar estos diseños en el codebase existente** (`tavero-parent/`) usando sus patrones, librerías y convenciones actuales (NativeWind para la app, Tailwind CSS para la web). No copies el HTML directamente.

## Fidelidad

**Alta fidelidad (hifi)** — Los prototipos son pixel-accurate con colores, tipografía, espaciado e interacciones finales. Recrea la UI lo más fielmente posible usando el sistema existente.

---

## Producto 1: tavero-app (Expo React Native)

### Pantallas

#### Login Screen (`src/app/(auth)/login.tsx`)

**Layout:**
- Fondo: `bg-background` (#F8FAFC)
- Scroll vertical con `flex-1 justify-center px-6 py-12`
- Hero centrado arriba, formulario abajo, link de registro al fondo

**Hero (logo + wordmark):**
- Logo: `w-16 h-16 rounded-2xl bg-primary` con letra "T" en blanco, `text-3xl font-bold`, `font-family: Inter`
- Wordmark: `text-4xl font-bold text-primary tracking-tight` → "Tavero"
- Subtítulo: `text-muted text-[15px]` → "Gestiona el menú de tu bar"
- Separación hero→formulario: `mb-10`

**Formulario:**
- Gap entre campos: `gap-4`
- Inputs: `bg-white border border-border rounded-xl px-4 py-3 text-base text-primary`
- Labels: `text-sm font-medium text-primary`
- Botón principal: `bg-primary rounded-xl px-5 py-3.5 font-semibold text-base text-white tracking-tight`, full width, `mt-2`
- Link "¿Olvidaste tu contraseña?": `text-muted text-sm`, accent en `text-accent font-semibold`

**Footer:**
- `mt-10 pt-6 border-t border-border items-center`
- "¿No tienes cuenta?" en `text-muted text-sm`, "Regístrate" en `text-accent font-semibold`

---

#### Dashboard Screen (`src/app/(app)/dashboard.tsx`)

**Header:**
- Logo/avatar del bar: `w-13 h-13 rounded-full` (52×52px), `bg-accentSoft` si no hay imagen
- Nombre bar: `text-xl font-bold text-primary tracking-tight`
- Eyebrow: `text-[11px] text-muted font-medium uppercase tracking-wider` → "Tu bar"
- "Salir": `text-muted text-sm font-medium`, top right

**QR Hero Card:**
- Card: `bg-surface rounded-2xl p-6 border border-borderSoft shadow-sm items-center gap-3`
- Eyebrow: `text-[11px] font-bold text-muted uppercase tracking-widest` → "Tu menú"
- QR wrapper: `p-4 bg-borderSoft rounded-2xl`
- QR size: 170×170px, `backgroundColor: #F5F5F4`, `color: #1C1917`
- URL: `text-xs text-muted text-center`
- Botón: `btn-accent` full width, `mt-1`

**Navigation Cards (NavCard):**
- Container: `gap-2.5`
- Cada card: `flex-row items-center`, Card component estándar
- Icon container: `w-11 h-11 rounded-xl bg-accentSoft items-center justify-center mr-3.5`
- Icono: emoji 20px (👀, 📂, 🍽️, ⚙️)
- Título: `text-[15px] font-semibold text-primary`
- Descripción: `text-[13px] text-muted mt-0.5`
- Chevron: `text-2xl text-mutedLight font-light` → "›"
- Press state: `opacity: pressed ? 0.85 : 1`

---

#### Categories Screen (`src/app/(app)/categories/`)

**Header:**
- Componente `<Header>` con back button + título "Categorías" + right action "+ Nueva" en `text-accent`
- Back button: `w-9 h-9 rounded-full bg-borderSoft`, texto "‹"

**Lista de categorías:**
- Cada item: Card con `flex-row items-center gap-3 py-2`
- Drag handle: `⋮⋮` en `text-mutedLight`
- Nombre: `text-[14px] font-semibold text-primary`
- Count: `text-xs text-muted`
- Badge: `bg-green-100 text-green-700` para "Activa", `bg-borderSoft text-muted` para "Inactiva"
- Chevron derecho

---

#### Products Screen (`src/app/(app)/products/`)

**Header:**
- Back + "Productos" + subtitle con categoría actual + "+ Añadir" en `text-accent`

**Lista de productos:**
- Cada item: Card `flex-row items-center gap-3`
- Thumbnail: `w-12 h-12 rounded-xl bg-borderSoft` con imagen o emoji
- Nombre: `text-[14px] font-semibold text-primary`, overflow ellipsis
- Precio: `text-[13px] font-bold text-accent`
- Badge activo/oculto

---

### Design Tokens (App — Slate + Emerald)

```js
// tailwind.config.js → theme.extend.colors
primary:      '#0F172A',  // slate-900
primaryLight: '#1E293B',  // slate-800
accent:       '#059669',  // emerald-600
accentSoft:   '#D1FAE5',  // emerald-100
surface:      '#FFFFFF',
background:   '#F8FAFC',  // slate-50
muted:        '#64748B',  // slate-500
mutedLight:   '#94A3B8',  // slate-400
border:       '#E2E8F0',  // slate-200
borderSoft:   '#F1F5F9',  // slate-100
danger:       '#DC2626',
success:      '#16A34A',
```

### Componentes a revisar/mejorar

| Componente | Mejora |
|---|---|
| `Button.tsx` | Press state: `opacity: pressed ? 0.85 : 1` (ya implementado) |
| `Card.tsx` | Shadow: `shadowOpacity: 0.04`, `shadowRadius: 6` (ya correcto) |
| `Input.tsx` | `rounded-xl`, `border-border` en normal, `border-danger` en error |
| `Badge.tsx` | Tres variantes: success, muted, accent |
| `Header.tsx` | Back button `rounded-full bg-borderSoft`, right label en `text-accent` |

---

## Producto 2: tavero-web (Next.js)

### Design Tokens (Web — Stone + Amber)

```css
/* globals.css :root */
--color-primary:      28 25 23;     /* #1C1917 stone-900 */
--color-accent:       217 119 6;    /* #D97706 amber-600 */
--color-accent-soft:  254 243 199;  /* #FEF3C7 amber-100 */
--color-muted:        120 113 108;  /* #78716C stone-500 */
--color-border:       231 229 228;  /* #E7E5E4 stone-200 */
--color-surface:      255 255 255;
--color-bg:           250 250 249;  /* #FAFAF9 stone-50 */
```

### MenuHeader (`src/components/MenuHeader.tsx`)

**Mejoras:**
- Fondo: `bg-gradient-to-br from-primary via-primary to-accent/30`
- Overlay radial: `bg-[radial-gradient(circle_at_top_right,rgba(245,158,11,0.25),transparent_60%)]`
- Logo placeholder (sin imagen): `bg-white/10 backdrop-blur border border-white/20 rounded-2xl`
- Logo con imagen: `rounded-2xl border-2 border-white/20 object-cover shadow-lg`
- Nombre: `text-3xl font-bold text-white tracking-tight`
- Descripción: `text-white/70 text-sm leading-relaxed`
- Theme toggle: `rounded-full bg-white/10 border border-white/20` — top right

### CategoryNav (`src/components/CategoryNav.tsx`)

**Mejoras:**
- Sticky: `sticky top-0 z-20`
- Fondo: `bg-bg/95 backdrop-blur-md border-b border-border`
- Pills: `rounded-full bg-surface border border-border text-xs font-semibold text-primary`
- Hover: `hover:bg-accentSoft hover:border-accent/40 transition-colors`
- Scroll horizontal suave, sin scrollbar visible

### ProductCard (`src/components/ProductCard.tsx`)

**Mejoras:**
- Separador: `border-b border-border last:border-0` (no cards, lista plana)
- Nombre: `font-semibold text-primary text-[15px] leading-snug`
- Descripción: `text-muted text-[13px] leading-relaxed line-clamp-2`
- Precio: `text-base font-bold text-accent tabular-nums` + `€` en `text-xs font-semibold text-accent/70`
- Imagen: `w-24 h-24 rounded-2xl object-cover ring-1 ring-border`
- Hover imagen: `group-hover:scale-105 transition-transform duration-300`

### Animaciones

```css
/* globals.css */
@media (prefers-reduced-motion: no-preference) {
  .animate-fade-in {
    animation: fade-in 0.4s ease-out;
  }
}
@keyframes fade-in {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

Aplicar `.animate-fade-in` a las secciones del menú al cargar.

---

## Tipografía

No hay fuente personalizada en el codebase. Se usa `system-ui / sans-serif`. Para mejorar: añadir **Inter** desde Google Fonts en `layout.tsx`:

```tsx
import { Inter } from 'next/font/google'
const inter = Inter({ subsets: ['latin'] })
// Aplicar: <body className={inter.className}>
```

En la app: NativeWind usa la fuente del sistema. No requiere cambios salvo que se quiera una fuente custom con expo-font.

---

## Archivos de referencia

```
ui_kits/app/index.html     — Prototipo interactivo app móvil (4 pantallas)
ui_kits/web/index.html     — Prototipo interactivo web menu viewer
colors_and_type.css        — Todos los tokens de color y tipografía
preview/                   — Tarjetas individuales de componentes
assets/logo.svg            — Logo actual (T en fondo oscuro, provisional)
```

## Notas finales

- El logo (`assets/logo.svg`) es **provisional** — se substituirá por el definitivo cuando esté listo
- El idioma de toda la UI es **español (es_ES)** — no cambiar a inglés
- Los emojis en la app son intencionales como iconos funcionales
- Dark mode está implementado en la web pero **desactivado en el menu viewer** — solo el dashboard admin lo soporta opcionalmente
